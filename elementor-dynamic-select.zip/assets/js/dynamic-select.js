(function () {
	'use strict';

	function normalizeValues(value) {
		if (Array.isArray(value)) {
			return value
				.map(function (item) {
					return String(item);
				})
				.filter(function (item) {
					return item !== '';
				});
		}

		if (value === null || value === undefined || value === '') {
			return [];
		}

		return [String(value)];
	}

	function normalizeExpected(expected) {
		return normalizeValues(expected);
	}

	function includesValue(actual, expected) {
		var expectedValues = normalizeExpected(expected);

		return expectedValues.some(function (value) {
			return actual.indexOf(value) !== -1;
		});
	}

	function includesAll(actual, expected) {
		var expectedValues = normalizeExpected(expected);

		return expectedValues.every(function (value) {
			return actual.indexOf(value) !== -1;
		});
	}

	function includesAny(actual, expected) {
		var expectedValues = normalizeExpected(expected);

		if (!expectedValues.length || !actual.length) {
			return false;
		}

		return expectedValues.some(function (value) {
			return actual.indexOf(value) !== -1;
		});
	}

	function equalsSet(actual, expected) {
		var expectedValues = normalizeExpected(expected).slice().sort();
		var actualValues = actual.slice().sort();

		if (actualValues.length !== expectedValues.length) {
			return false;
		}

		return actualValues.every(function (value, index) {
			return value === expectedValues[index];
		});
	}

	function inValue(actual, expected) {
		var expectedValues = normalizeExpected(expected);

		if (!expectedValues.length || !actual.length) {
			return false;
		}

		return actual.some(function (value) {
			return expectedValues.indexOf(value) !== -1;
		});
	}

	function conditionMatches(condition, sourceValues) {
		var field = condition.field || '';
		var operator = condition.operator || 'includes';
		var actual = normalizeValues(sourceValues[field]);

		switch (operator) {
			case 'includes':
				return includesValue(actual, condition.value);
			case 'includesAll':
				return includesAll(actual, condition.value);
			case 'includesAny':
			case 'intersects':
				return includesAny(actual, condition.value);
			case 'equals':
				return equalsSet(actual, condition.value);
			case 'in':
				return inValue(actual, condition.value);
			case 'any':
				return actual.length > 0;
			default:
				return false;
		}
	}

	function ruleMatches(rule, sourceValues) {
		var when = rule.when || {};
		var group;
		var conditions;
		var anyMatch;

		if (when.all && when.all.length) {
			for (group = 0; group < when.all.length; group += 1) {
				if (!conditionMatches(when.all[group], sourceValues)) {
					return false;
				}
			}
		}

		if (when.any && when.any.length) {
			anyMatch = false;
			for (group = 0; group < when.any.length; group += 1) {
				if (conditionMatches(when.any[group], sourceValues)) {
					anyMatch = true;
					break;
				}
			}

			if (!anyMatch) {
				return false;
			}
		}

		return true;
	}

	function resolveOptions(block, optionSets) {
		if (block.use && optionSets[block.use]) {
			return optionSets[block.use].slice();
		}

		if (block.options && block.options.length) {
			return block.options.slice();
		}

		return [];
	}

	function mergeOptions(existing, incoming) {
		var merged = {};
		var result = [];
		var index;

		for (index = 0; index < existing.length; index += 1) {
			merged[existing[index].value] = existing[index];
		}

		for (index = 0; index < incoming.length; index += 1) {
			merged[incoming[index].value] = incoming[index];
		}

		Object.keys(merged).forEach(function (key) {
			result.push(merged[key]);
		});

		return result;
	}

	function evaluateRuleset(ruleset, sourceValues) {
		var behavior = ruleset.behavior || {};
		var matchMode = behavior.match || 'first';
		var optionSets = ruleset.optionSets || {};
		var rules = ruleset.rules || [];
		var matched = [];
		var index;
		var options;

		for (index = 0; index < rules.length; index += 1) {
			if (!ruleMatches(rules[index], sourceValues)) {
				continue;
			}

			options = resolveOptions(rules[index], optionSets);

			if (matchMode === 'first') {
				return options;
			}

			matched = mergeOptions(matched, options);
		}

		if (matched.length) {
			return matched;
		}

		if (ruleset.default) {
			return resolveOptions(ruleset.default, optionSets);
		}

		return [];
	}

	function getFormElement(select) {
		return select.closest('form.elementor-form');
	}

	function getFieldInputs(form, fieldId) {
		var selectors = [
			'[name="form_fields[' + fieldId + ']"]',
			'[name="form_fields[' + fieldId + '][]"]'
		];

		return Array.prototype.slice.call(form.querySelectorAll(selectors.join(',')));
	}

	function readFieldValues(inputs) {
		var values = [];

		inputs.forEach(function (input) {
			if (input.type === 'checkbox' || input.type === 'radio') {
				if (input.checked) {
					values.push(String(input.value));
				}
				return;
			}

			if (input.tagName === 'SELECT' && input.multiple) {
				Array.prototype.slice.call(input.selectedOptions).forEach(function (option) {
					if (option.value !== '') {
						values.push(String(option.value));
					}
				});
				return;
			}

			if (input.value !== '') {
				values.push(String(input.value));
			}
		});

		return values;
	}

	function collectSourceValues(form, sources) {
		var sourceValues = {};
		var index;

		for (index = 0; index < sources.length; index += 1) {
			sourceValues[sources[index]] = readFieldValues(getFieldInputs(form, sources[index]));
		}

		return sourceValues;
	}

	function createOption(value, label, selected) {
		var option = document.createElement('option');
		option.value = value;
		option.textContent = label;

		if (selected) {
			option.selected = true;
		}

		return option;
	}

	function rebuildSelect(select, options, ruleset) {
		var behavior = ruleset.behavior || {};
		var preserveSelection = behavior.preserveSelection !== false;
		var placeholder = select.getAttribute('data-eds-placeholder') || 'Select an option';
		var noMatchText = select.getAttribute('data-eds-no-match') || 'No options available';
		var previousValue = select.value;
		var nextValue = '';
		var index;

		select.innerHTML = '';

		if (!options.length) {
			select.appendChild(createOption('', noMatchText, true));
			select.disabled = true;
			select.value = '';
			return;
		}

		select.disabled = false;
		select.appendChild(createOption('', placeholder, false));

		for (index = 0; index < options.length; index += 1) {
			select.appendChild(
				createOption(
					String(options[index].value),
					String(options[index].label || options[index].value),
					false
				)
			);
		}

		if (preserveSelection && previousValue) {
			Array.prototype.slice.call(select.options).forEach(function (option) {
				if (option.value === previousValue) {
					nextValue = previousValue;
				}
			});
		}

		select.value = nextValue;
	}

	function updateSelect(select) {
		var form = getFormElement(select);

		if (!form) {
			return;
		}

		var ruleset;
		var sources;
		var sourceValues;
		var options;

		try {
			ruleset = JSON.parse(select.getAttribute('data-eds-rules') || '{}');
		} catch (error) {
			return;
		}

		if (!ruleset || !ruleset.rules) {
			return;
		}

		try {
			sources = JSON.parse(select.getAttribute('data-eds-sources') || '[]');
		} catch (sourcesError) {
			sources = [];
		}

		if (!sources.length && ruleset.sources) {
			sources = ruleset.sources;
		}

		sourceValues = collectSourceValues(form, sources);
		options = evaluateRuleset(ruleset, sourceValues);
		rebuildSelect(select, options, ruleset);
	}

	function bindSelect(select) {
		var form = getFormElement(select);

		if (!form || select.dataset.edsBound === '1') {
			return;
		}

		select.dataset.edsBound = '1';

		var sources;

		try {
			sources = JSON.parse(select.getAttribute('data-eds-sources') || '[]');
		} catch (error) {
			sources = [];
		}

		var ruleset;

		try {
			ruleset = JSON.parse(select.getAttribute('data-eds-rules') || '{}');
		} catch (rulesError) {
			ruleset = {};
		}

		if (!sources.length && ruleset.sources) {
			sources = ruleset.sources;
		}

		sources.forEach(function (sourceId) {
			getFieldInputs(form, sourceId).forEach(function (input) {
				input.addEventListener('change', function () {
					updateSelect(select);
				});
				input.addEventListener('input', function () {
					updateSelect(select);
				});
			});
		});

		updateSelect(select);
	}

	function initDynamicSelects(context) {
		var root = context || document;
		var selects = root.querySelectorAll('select.eds-dynamic-select[data-eds-rules]');

		Array.prototype.forEach.call(selects, function (select) {
			bindSelect(select);
			updateSelect(select);
		});
	}

	function getPopupRoot(event, id, instance) {
		if (instance && instance.$elements && instance.$elements.length) {
			return instance.$elements[0];
		}

		if (event && event.detail && event.detail.instance && event.detail.instance.$elements) {
			return event.detail.instance.$elements[0];
		}

		if (id) {
			var popupModal = document.getElementById('elementor-popup-modal-' + id);

			if (popupModal) {
				return popupModal;
			}
		}

		return document;
	}

	function registerElementorHooks() {
		if (typeof jQuery === 'undefined' || typeof elementorFrontend === 'undefined') {
			return;
		}

		elementorFrontend.hooks.addAction('frontend/element_ready/form.default', function ($scope) {
			initDynamicSelects($scope[0]);
		});

		if (elementorFrontend.hooks.addAction) {
			elementorFrontend.hooks.addAction('popup:after_open', function (id, instance) {
				initDynamicSelects(getPopupRoot(null, id, instance));
			});
		}

		jQuery(document).on('elementor/popup/show', function (event, id, instance) {
			initDynamicSelects(getPopupRoot(event, id, instance));
		});
	}

	function boot() {
		initDynamicSelects(document);

		if (typeof jQuery !== 'undefined') {
			jQuery(function () {
				if (typeof elementorFrontend !== 'undefined') {
					registerElementorHooks();
				} else {
					jQuery(window).on('elementor/frontend/init', registerElementorHooks);
				}
			});
		}

		document.addEventListener('elementor/popup/show', function (event) {
			initDynamicSelects(getPopupRoot(event));
		});
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', boot);
	} else {
		boot();
	}

	window.EDS = window.EDS || {};
	window.EDS.initDynamicSelects = initDynamicSelects;
	window.EDS.evaluateRuleset = evaluateRuleset;
})();
